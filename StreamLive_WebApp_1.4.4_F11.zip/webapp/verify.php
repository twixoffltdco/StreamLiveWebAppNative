<?php
header("Content-Type: text/html; charset=utf-8");
header("Cache-Control: no-store");
$js=(string)@file_get_contents(dirname(__DIR__)."/assets/webapp/app.js");
$ok=strpos($js,"1.4.4-F11")!==false && strpos($js,"location.reload")===false || (strpos($js,"no auto-reload")!==false);
$ok2=strpos($js,"Нет связи с auth API")!==false || strpos($js,"/webapp/api/native_auth.php")!==false;
echo "<meta name=viewport content=\"width=device-width,initial-scale=1\"><body style=\"background:#050d20;color:#fff;font:15px system-ui;padding:20px\">";
echo "<h1>1.4.4 <b style=color:#7C4DFF>F11</b> · auth fix</h1>";
echo ($ok2)?"<p style=color:#4ADE80>OK · <a style=color:#22D3EE href=/webapp/?v=1452>открыть</a></p>":"<p style=color:#FF8AA8>FAIL</p>";
echo "<p>Убран auto-reload при логине · auth через /webapp/api/</p>";
