<?php
header("Content-Type: text/html; charset=utf-8");
header("Cache-Control: no-store");
$js=(string)@file_get_contents(dirname(__DIR__)."/assets/webapp/app.js");
$bj=(string)@file_get_contents(dirname(__DIR__)."/webapp/build.json");
$ok=strpos($js,"1.4.4-F4")!==false && strpos($js,"channelThumbSrc")!==false && strpos($bj,"1444")!==false;
echo "<meta name=viewport content=\"width=device-width,initial-scale=1\"><body style=\"background:#050d20;color:#fff;font:15px system-ui;padding:20px\">";
echo "<h1>1.4.4 <b style=color:#7C4DFF>F4</b> · 1444</h1>";
echo $ok?"<p style=color:#4ADE80>OK · <a style=color:#22D3EE href=/webapp/?v=1444>открыть</a></p>":"<p style=color:#FF8AA8>FAIL</p>";
echo "<p>Превью каналов без PHP-хитов · проверка обновлений</p>";
