F33 phone gate fix - upload api/native_auth.php
