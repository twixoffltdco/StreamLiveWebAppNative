FIX: 2FA + телефон ломают вход только через APP
================================================

ПРИЧИНА
  includes/auth.php при каждом подключении вызывает:
    enforce_2fa_gate()  → redirect /auth/2fa_setup.php
    enforce_phone_gate() → redirect /auth/add_phone.php
  Пути /api/native_* и /webapp/api/native_* НЕ были в whitelist.
  После login через app любой native API получал HTML-редирект →
  приложение пустое / ошибка, на сайте — «переадресация».

ЧТО ИЗМЕНЕНО
1) includes/auth.php
   - native API пути исключены из редиректов phone/2FA

2) api/native_auth.php  (+ копия webapp/api/native_auth.php)
   - user: need_phone, has_phone, need_2fa_setup, totp_enabled
   - action set_phone / add_phone — сохранить телефон из app
   - force_2fa больше не режет login 403 (флаг need_2fa_setup)

3) assets/webapp/app.js
   - после входа/me: модалка «Укажите телефон»
   - вызов set_phone

УСТАНОВКА НА СЕРВЕР (PHP StreamLive)
  includes/auth.php          ← заменить или вмержить правки gate
  api/native_auth.php        ← заменить
  webapp/api/native_auth.php ← если используете webapp/api/
  assets/webapp/app.js       ← WebApp
  (и webapp/assets/webapp/app.js если дублируется)

Порядок: сначала auth.php + native_auth.php, потом app.js.
