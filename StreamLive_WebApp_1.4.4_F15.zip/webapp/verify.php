<?php
header("Content-Type: text/html; charset=utf-8");
header("Cache-Control: no-store");
$js=(string)@file_get_contents(dirname(__DIR__)."/assets/webapp/app.js");
$ok=strpos($js,"1.4.4-F15")!==false;
echo "<h1>F15</h1>";
echo $ok?"OK <a href=/webapp/?v=1457>open</a>":"FAIL";
