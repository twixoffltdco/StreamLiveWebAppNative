<?php
/**
 * JSON-комментарии канала + модерация (как chat_ban / comment_delete на сайте).
 * GET  ?channel_id=1&after=0
 * POST {action:"send", channel_id, message}
 * POST {action:"delete", channel_id, comment_id}  — soft-delete + ban автора на канале
 * POST {action:"ban", channel_id, user_id}
 */
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-API-KEY, Cookie');
header('Access-Control-Allow-Credentials: true');
header('Cache-Control: no-store');

function nc_out(array $a, int $code = 200): void {
  http_response_code($code);
  echo json_encode($a, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function nc_is_mod(int $channelId, array $user): bool {
  if (function_exists('is_channel_moderator')) {
    try { return (bool)is_channel_moderator($channelId, (int)$user['id']); } catch (Throwable $e) {}
  }
  $role = strtolower((string)($user['role'] ?? ''));
  if (in_array($role, ['admin', 'moderator'], true)) return true;
  try {
    $st = db()->prepare('SELECT owner_id FROM channels WHERE id = ? LIMIT 1');
    $st->execute([$channelId]);
    $ch = $st->fetch();
    if ($ch && (int)$ch['owner_id'] === (int)$user['id']) return true;
  } catch (Throwable $e) {}
  return false;
}

function nc_is_chat_banned(int $channelId, int $userId): bool {
  try {
    $st = db()->prepare('SELECT id FROM chat_bans WHERE channel_id = ? AND user_id = ? LIMIT 1');
    $st->execute([$channelId, $userId]);
    return (bool)$st->fetch();
  } catch (Throwable $e) {
    return false;
  }
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$user = function_exists('current_user') ? current_user() : null;

if ($method === 'GET') {
  $channelId = (int)($_GET['channel_id'] ?? 0);
  $after = (int)($_GET['after'] ?? 0);
  if ($channelId <= 0) nc_out(['ok' => false, 'messages' => []], 400);

  $meBanned = false;
  if ($user && nc_is_chat_banned($channelId, (int)$user['id'])) {
    $meBanned = true;
  }

  try {
    $st = db()->prepare(
      'SELECT cm.id, cm.message, cm.created_at, cm.user_id,
              u.username, u.is_verified, u.role
       FROM comments cm JOIN users u ON u.id = cm.user_id
       WHERE cm.channel_id = ? AND cm.is_deleted = 0 AND cm.id > ?
       ORDER BY cm.id ASC LIMIT 50'
    );
    $st->execute([$channelId, $after]);
    $rows = $st->fetchAll();
    $messages = array_map(static function ($r) {
      $role = strtolower((string)($r['role'] ?? 'user'));
      return [
        'id' => (int)$r['id'],
        'userId' => (int)$r['user_id'],
        'username' => $r['username'],
        'message' => $r['message'],
        'created_at' => $r['created_at'],
        'is_verified' => !empty($r['is_verified']),
        'role' => $role,
        'is_mod' => in_array($role, ['admin', 'moderator'], true),
      ];
    }, $rows);
    $canMod = $user ? nc_is_mod($channelId, $user) : false;
    nc_out([
      'ok' => true,
      'messages' => $messages,
      'comments' => $messages,
      'me_banned' => $meBanned,
      'can_moderate' => $canMod,
    ]);
  } catch (Throwable $e) {
    nc_out(['ok' => false, 'messages' => [], 'error' => 'db'], 500);
  }
}

if ($method === 'POST') {
  if (!$user) nc_out(['ok' => false, 'error' => 'Нужно войти'], 401);
  $input = json_decode(file_get_contents('php://input') ?: '{}', true) ?: [];
  $action = strtolower(trim((string)($input['action'] ?? 'send')));
  $channelId = (int)($input['channel_id'] ?? 0);
  if ($channelId <= 0) nc_out(['ok' => false, 'error' => 'channel_id'], 400);

  if ($action === 'send' || $action === '') {
    if (nc_is_chat_banned($channelId, (int)$user['id'])) {
      nc_out(['ok' => false, 'error' => 'Вас заблокировали в этом канале', 'me_banned' => true], 403);
    }
    $message = trim(mb_substr((string)($input['message'] ?? ''), 0, 1000));
    if ($message === '') nc_out(['ok' => false, 'error' => 'Пустое сообщение'], 400);
    $st = db()->prepare("SELECT id FROM channels WHERE id = ? AND status = 'approved'");
    $st->execute([$channelId]);
    if (!$st->fetch()) nc_out(['ok' => false, 'error' => 'Канал не найден'], 404);
    try {
      db()->prepare('INSERT INTO comments (channel_id, user_id, message) VALUES (?, ?, ?)')
        ->execute([$channelId, (int)$user['id'], $message]);
      nc_out(['ok' => true, 'id' => (int)db()->lastInsertId()]);
    } catch (Throwable $e) {
      nc_out(['ok' => false, 'error' => 'Не удалось сохранить'], 500);
    }
  }

  if ($action === 'delete') {
    if (!nc_is_mod($channelId, $user)) nc_out(['ok' => false, 'error' => 'Нет прав'], 403);
    $commentId = (int)($input['comment_id'] ?? 0);
    if ($commentId <= 0) nc_out(['ok' => false, 'error' => 'comment_id'], 400);
    $st = db()->prepare('SELECT user_id FROM comments WHERE id = ? AND channel_id = ?');
    $st->execute([$commentId, $channelId]);
    $comment = $st->fetch();
    if (!$comment) nc_out(['ok' => false, 'error' => 'Не найдено'], 404);
    db()->prepare('UPDATE comments SET is_deleted = 1 WHERE id = ? AND channel_id = ?')
      ->execute([$commentId, $channelId]);
    // как на сайте: бан автора на канале (кроме владельца)
    try {
      $ch = db()->prepare('SELECT owner_id FROM channels WHERE id = ?');
      $ch->execute([$channelId]);
      $crow = $ch->fetch();
      $authorId = (int)$comment['user_id'];
      if ($crow && $authorId !== (int)$crow['owner_id'] && $authorId !== (int)$user['id']) {
        db()->prepare('INSERT IGNORE INTO chat_bans (channel_id, user_id) VALUES (?, ?)')
          ->execute([$channelId, $authorId]);
        // soft-delete all his messages in this channel
        db()->prepare('UPDATE comments SET is_deleted = 1 WHERE channel_id = ? AND user_id = ?')
          ->execute([$channelId, $authorId]);
      }
    } catch (Throwable $e) {}
    nc_out(['ok' => true]);
  }

  if ($action === 'ban') {
    if (!nc_is_mod($channelId, $user)) nc_out(['ok' => false, 'error' => 'Нет прав'], 403);
    $target = (int)($input['user_id'] ?? 0);
    if ($target <= 0) nc_out(['ok' => false, 'error' => 'user_id'], 400);
    try {
      db()->prepare('INSERT IGNORE INTO chat_bans (channel_id, user_id) VALUES (?, ?)')
        ->execute([$channelId, $target]);
      db()->prepare('UPDATE comments SET is_deleted = 1 WHERE channel_id = ? AND user_id = ?')
        ->execute([$channelId, $target]);
    } catch (Throwable $e) {
      nc_out(['ok' => false, 'error' => 'db'], 500);
    }
    nc_out(['ok' => true]);
  }

  nc_out(['ok' => false, 'error' => 'unknown action'], 400);
}

nc_out(['ok' => false, 'error' => 'method'], 405);
