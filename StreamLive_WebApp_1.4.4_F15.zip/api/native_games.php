<?php
/**
 * Платные игры StreamLive (искры сгорают у покупателя, автору не начисляются).
 * Автосоздание таблицы paid_games при первом запросе.
 *
 * GET  ?action=list
 * POST {action:"submit", title, url, price_sparks, description?}
 * POST {action:"buy", id}  — клиент списывает искры локально; сервер логирует покупку если залогинен
 * POST {action:"moderate", id, status} — admin/mod only: approved|rejected
 */
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-API-KEY, Cookie');
header('Access-Control-Allow-Credentials: true');
header('Cache-Control: no-store');

function ng_out(array $a, int $code = 200): void {
  http_response_code($code);
  echo json_encode($a, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function ng_ensure_table(): void {
  static $done = false;
  if ($done) return;
  $done = true;
  try {
    db()->exec("CREATE TABLE IF NOT EXISTS paid_games (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id INT UNSIGNED NOT NULL,
      title VARCHAR(150) NOT NULL,
      description VARCHAR(1000) DEFAULT '',
      url VARCHAR(500) NOT NULL,
      price_sparks INT UNSIGNED NOT NULL DEFAULT 50,
      status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  } catch (Throwable $e) {}
}

ng_ensure_table();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$user = function_exists('current_user') ? current_user() : null;
$input = [];
if ($method === 'POST') {
  $input = json_decode(file_get_contents('php://input') ?: '{}', true) ?: [];
}
$action = strtolower(trim((string)($_GET['action'] ?? $input['action'] ?? 'list')));

if ($action === 'list') {
  $status = 'approved';
  $isStaff = $user && in_array(strtolower((string)($user['role'] ?? '')), ['admin','moderator'], true);
  try {
    if ($isStaff) {
      $rows = db()->query('SELECT pg.*, u.username FROM paid_games pg LEFT JOIN users u ON u.id = pg.user_id ORDER BY pg.id DESC LIMIT 100')->fetchAll();
    } else {
      $st = db()->prepare("SELECT pg.id, pg.title, pg.description, pg.url, pg.price_sparks, pg.status, u.username
                           FROM paid_games pg LEFT JOIN users u ON u.id = pg.user_id
                           WHERE pg.status = 'approved' ORDER BY pg.id DESC LIMIT 50");
      $st->execute();
      $rows = $st->fetchAll();
    }
  } catch (Throwable $e) {
    $rows = [];
  }
  ng_out(['ok' => true, 'games' => $rows]);
}

if ($method === 'POST' && $action === 'submit') {
  if (!$user) ng_out(['ok' => false, 'error' => 'Нужно войти'], 401);
  $title = trim(mb_substr((string)($input['title'] ?? ''), 0, 150));
  $url = trim(mb_substr((string)($input['url'] ?? ''), 0, 500));
  $desc = trim(mb_substr((string)($input['description'] ?? ''), 0, 1000));
  $price = max(1, min(100000, (int)($input['price_sparks'] ?? 50)));
  if ($title === '' || $url === '') ng_out(['ok' => false, 'error' => 'title/url'], 400);
  if (!preg_match('#^https?://#i', $url)) ng_out(['ok' => false, 'error' => 'URL должен начинаться с http'], 400);
  try {
    db()->prepare('INSERT INTO paid_games (user_id, title, description, url, price_sparks, status) VALUES (?,?,?,?,?,"pending")')
      ->execute([(int)$user['id'], $title, $desc, $url, $price]);
    ng_out(['ok' => true, 'id' => (int)db()->lastInsertId(), 'status' => 'pending']);
  } catch (Throwable $e) {
    ng_out(['ok' => false, 'error' => 'db'], 500);
  }
}

if ($method === 'POST' && $action === 'moderate') {
  if (!$user || !in_array(strtolower((string)($user['role'] ?? '')), ['admin','moderator'], true)) {
    ng_out(['ok' => false, 'error' => 'Нет прав'], 403);
  }
  $id = (int)($input['id'] ?? 0);
  $status = strtolower(trim((string)($input['status'] ?? '')));
  if (!in_array($status, ['approved','rejected','pending'], true) || $id <= 0) {
    ng_out(['ok' => false, 'error' => 'params'], 400);
  }
  db()->prepare('UPDATE paid_games SET status = ? WHERE id = ?')->execute([$status, $id]);
  ng_out(['ok' => true]);
}

if ($method === 'POST' && $action === 'buy') {
  // Искры списываются на клиенте; сервер только подтверждает что игра approved
  $id = (int)($input['id'] ?? 0);
  $st = db()->prepare("SELECT id, title, url, price_sparks FROM paid_games WHERE id = ? AND status = 'approved'");
  $st->execute([$id]);
  $g = $st->fetch();
  if (!$g) ng_out(['ok' => false, 'error' => 'Игра недоступна'], 404);
  ng_out(['ok' => true, 'game' => $g, 'note' => 'sparks_burned_client_side']);
}

ng_out(['ok' => false, 'error' => 'method'], 405);
