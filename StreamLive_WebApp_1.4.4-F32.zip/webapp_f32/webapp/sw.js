/* StreamLive PWA service worker — build 1474 */
'use strict';
const CACHE_NAME = 'streamlive-static-v1474';
const DATA_CACHE = 'streamlive-data-v1';
const APP_SCOPE = '/webapp/';
const PRECACHE = [
  '/webapp/',
  '/webapp/index.html',
  '/webapp/manifest.webmanifest',
  '/assets/webapp/app.css?v=1474',
  '/assets/webapp/app.js?v=1474',
  '/assets/webapp/doodles.js',
  '/assets/webapp/games.js'
];
self.addEventListener('install', event => event.waitUntil((async () => {
  const cache = await caches.open(CACHE_NAME);
  await Promise.all(PRECACHE.map(url => cache.add(url).catch(() => null)));
  await self.skipWaiting();
})()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  const keys = await caches.keys();
  await Promise.all(keys.filter(k => k.startsWith('streamlive-static-') && k !== CACHE_NAME).map(k => caches.delete(k)));
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});
self.addEventListener('push', event => {
  let payload = { title: 'StreamLive', body: '', data: {} };
  try {
    if (event.data) payload = Object.assign(payload, event.data.json());
  } catch (e) {
    try { payload.body = event.data && event.data.text(); } catch (e2) {}
  }
  event.waitUntil(self.registration.showNotification(payload.title || 'StreamLive', {
    body: payload.body || '',
    icon: '/assets/webapp/icons/icon-192.png',
    badge: '/assets/webapp/icons/icon-72.png',
    data: payload.data || {}
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const data = event.notification.data || {};
  event.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    if (all.length) {
      all[0].focus();
      all[0].postMessage({ type: 'SL_NOTIFICATION_CLICK', data: data });
      return;
    }
    await self.clients.openWindow('/webapp/?v=1474');
  })());
});
self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;
  if (url.pathname.indexOf('/api/native_home.php') !== -1 ||
      url.pathname.indexOf('/api/native_videos.php') !== -1 ||
      url.pathname.indexOf('/webapp/api/native_home.php') !== -1 ||
      url.pathname.indexOf('/webapp/api/native_videos.php') !== -1) {
    event.respondWith((async () => {
      const cache = await caches.open(DATA_CACHE);
      try {
        const res = await fetch(req);
        if (res && res.ok) cache.put(req, res.clone());
        return res;
      } catch (e) {
        const cached = await cache.match(req);
        if (cached) return cached;
        return new Response(JSON.stringify({ ok: false, offline: true, channels: [], videos: [] }), {
          headers: { 'Content-Type': 'application/json' }
        });
      }
    })());
    return;
  }
  if (url.pathname.includes('/api/') || /\/(message_poll|message_send)\.php$/.test(url.pathname) || url.searchParams.has('action')) return;
  if (url.pathname.startsWith('/assets/webapp/')) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(req);
      const network = fetch(req).then(res => { if (res && res.ok) cache.put(req, res.clone()); return res; }).catch(() => null);
      return cached || await network || new Response('', { status: 504, statusText: 'Offline' });
    })());
  } else if (url.pathname.startsWith(APP_SCOPE)) {
    event.respondWith((async () => {
      try {
        const res = await fetch(req, { cache: 'no-store' });
        if (res && res.ok && (req.mode === 'navigate' || url.pathname.endsWith('.html'))) {
          const cache = await caches.open(CACHE_NAME);
          cache.put('/webapp/index.html', res.clone());
        }
        return res;
      } catch (_) {
        const cache = await caches.open(CACHE_NAME);
        return await cache.match('/webapp/index.html') || await cache.match('/webapp/') || new Response('Offline', { status: 503 });
      }
    })());
  }
});
