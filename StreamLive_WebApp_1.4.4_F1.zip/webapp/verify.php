<?php
header("Content-Type: text/html; charset=utf-8");
header("Cache-Control: no-store");
$root = dirname(__DIR__);
$js = (string)@file_get_contents("$root/assets/webapp/app.js");
$checks = [
  "version F1" => strpos($js, "1.4.4-F1") !== false,
  "channel?slug=" => strpos($js, "/channel?slug=") !== false,
  "no /channel/+" => strpos($js, "/channel/' +") === false && strpos($js, '/channel/" +') === false,
  "player chrome" => strpos($js, "attachPlayerChrome") !== false,
  "episodes" => strpos($js, "parseEpisodeInfo") !== false,
  "dev about" => strpos($js, "about.onclick") !== false,
];
echo "<meta name=viewport content=\"width=device-width,initial-scale=1\"><body style=\"background:#050d20;color:#fff;font:15px system-ui;padding:20px\">";
echo "<h1>StreamLive <b style=color:#7C4DFF>1.4.4 F1</b> · build 1441</h1><ul>";
$ok=true;
foreach($checks as $k=>$v){ if(!$v)$ok=false; echo "<li style=color:".($v?"#4ADE80":"#FF8AA8").">$k — ".($v?"OK":"FAIL")."</li>"; }
echo "</ul>";
echo $ok?"<p style=color:#4ADE80><b>OK</b> · <a style=color:#22D3EE href=/webapp/?v=1441>открыть</a></p>":"<p style=color:#FF8AA8>FAIL</p>";
